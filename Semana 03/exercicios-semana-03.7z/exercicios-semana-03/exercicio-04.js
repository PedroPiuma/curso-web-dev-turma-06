const tabuada = (valorUm, valorDois) => {
    for (let i = 1; i <= valorDois; i++) {
        console.log(`${valorUm} x ${i} = ${valorUm * i}`)
    }
}
tabuada(5, 15)