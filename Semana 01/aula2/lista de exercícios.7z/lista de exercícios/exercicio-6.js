const salarioFixo = 2000
const valorTotalVendido = 30000
const porcentagemDaComissao = 1

const valorTotalRecebido = salarioFixo + (valorTotalVendido * (porcentagemDaComissao / 100))

console.log('Valor Mensal: R$' + valorTotalRecebido)