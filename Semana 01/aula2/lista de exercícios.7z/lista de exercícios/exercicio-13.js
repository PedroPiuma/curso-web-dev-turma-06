const number = 2

if (number % 2 === 0) {
    console.log('Par')
} else {
    console.log('Ímpar')
}