const name = 'Luís'
const lastName = 'Piúma'
const fullName = name + ' ' + lastName
console.log(fullName)