let valor1 = 3
let valor2 = 12
console.log('Valor 1 = ' + valor1)
console.log('Valor 2 = ' + valor2)

let registerValue
registerValue = valor1
valor1 = valor2
valor2 = registerValue
console.log('Valor 1 = ' + valor1)
console.log('Valor 2 = ' + valor2)
