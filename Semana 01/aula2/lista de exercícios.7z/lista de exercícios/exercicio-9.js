const name = 'Luís'
const old = 22

if (old >= 18) {
    console.log(name + ' é maior de idade.')
} else {
    console.log(name + ' não é maior de idade.')
}