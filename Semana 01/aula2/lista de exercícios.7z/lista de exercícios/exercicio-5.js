const valor1 = 1
const valor2 = 2
const resultado = valor1 + valor2
console.log(resultado)

