const stringOne = 'Otter'
const stringTwo = 'wise'
const sum = stringOne + stringTwo
console.log(sum)