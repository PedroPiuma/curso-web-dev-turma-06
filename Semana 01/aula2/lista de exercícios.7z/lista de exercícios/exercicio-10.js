const numberOne = 7
const numberTwo = 7

if (numberOne > numberTwo) {
    console.log(numberOne + ' é maior que ' + numberTwo)
} else if (numberOne < numberTwo) {
    console.log(numberTwo + ' é maior que ' + numberOne)
} else {
    console.log(numberTwo + ' e ' + numberOne + ' são iguais.')
}