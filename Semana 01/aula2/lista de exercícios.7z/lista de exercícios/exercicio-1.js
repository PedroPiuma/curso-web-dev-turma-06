const name = 'Olá mundo, eu me chamo Luís Piúma e sou estudante de química na UFPel e programação na Otterwise'
console.log(name)